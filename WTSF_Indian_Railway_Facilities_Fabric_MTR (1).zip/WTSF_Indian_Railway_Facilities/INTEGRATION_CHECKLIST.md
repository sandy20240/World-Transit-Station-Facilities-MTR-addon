# Integration checklist

- [x] Indian Railway facility model JSON
- [x] Blockstate JSON
- [x] Item model JSON
- [x] PNG placeholder textures
- [x] English localization
- [x] Fabric resource overlay
- [x] MTR 4.0.5 compatibility note
- [ ] Pin Minecraft/Fabric API versions from gradle.properties
- [ ] Register blocks/items in Fabric Java
- [ ] Add creative-tab entries
- [ ] Run Gradle compile
- [ ] Test placement/rotation in an MTR world
