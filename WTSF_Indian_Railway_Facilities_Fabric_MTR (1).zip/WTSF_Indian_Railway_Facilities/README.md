# WTSF — Indian Railway Facilities Pack

Fabric/Minecraft Transit Railway (MTR) addon overlay for:
`sandy20240/World-Transit-Facilities-Addon-forker`

## Scope

Full Indian Railway facilities pack, using a modern + classic visual mix:

1. Station sign
2. Platform number sign
3. Ticket counter
4. Ticket machine
5. Reservation counter
6. Platform bench
7. Station clock
8. Drinking water point
9. Dustbin
10. Chai stall
11. Food stall
12. Station toilet

## Compatibility findings

The repository currently declares the MTR Fabric dependency as:

`mtr:mtr-fabric:4.0.5`

The repository also uses Architectury Loom and targets Java 17.

The existing repository does **not** expose a complete, version-pinned `gradle.properties` in the visible tree, so this package deliberately avoids hard-coding Minecraft/Fabric API versions that could make the project fail to compile.

The package therefore supplies the **resource/model layer** first:
- blockstate JSON
- block model JSON
- item model JSON
- PNG textures
- English language names

These files are an overlay and do not replace the existing MTR dependency or mod metadata.

## Install / merge

Copy the `fabric/` directory from this package into the repository root and merge folders.

Expected destination examples:

`fabric/src/main/resources/assets/wtsf/models/block/ir_station_sign.json`

`fabric/src/main/resources/assets/wtsf/blockstates/ir_station_sign.json`

`fabric/src/main/resources/assets/wtsf/textures/block/ir_station_sign.png`

## Registration

The existing repository currently has no visible Fabric block-registration source under `fabric/src/main/java` and its current tree is very sparse. The JSON resources will only become placeable Minecraft blocks after corresponding Java block/item registration is added.

Registration should use the exact Minecraft/Fabric API versions from the project's final `gradle.properties`, rather than guessing them from the MTR version.

## MTR relationship

This is designed as a facility/content layer for the existing MTR addon. It does not attempt to duplicate MTR's railway, route, station, or vehicle systems.

## Design direction

The assets intentionally mix:
- classic Indian Railways yellow/green signage
- practical platform furniture
- contemporary ticketing/service equipment
- recognizable station-service silhouettes

The PNGs are placeholder production textures for the first implementation pass and are deliberately easy to replace with detailed Blockbench textures.
